// src/models/commonRailModelCr7.js

const pool = require("../config/db_core");


// Untuk common_rail_7
const getAllCr7 = async () => {
  const [rows] = await pool.query("SELECT * FROM common_rail_7_core ORDER BY idPrimary DESC");
  return rows;
};

const getByIdCr7 = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_7_core WHERE idPrimary = ?", [id]);
  return rows[0];
};


const getAllCr7Stop = async () => {
  const [rows] = await pool.query(
    "SELECT * FROM common_rail_7_core WHERE status = 'STOP' ORDER BY idPrimary DESC"
  );
  return rows;
};




// Untuk common_rail_7
// const getAllCr7Hourly = async () => {
//   const [rows] = await pool.query("SELECT * FROM common_rail_7_hourly ORDER BY idPrimary DESC");
//   return rows;
// };

// const getByIdCr7Hourly = async (id) => {
//   const [rows] = await pool.query("SELECT * FROM common_rail_7 WHERE idPrimary = ?", [id]);
//   return rows[0];
// };


// const getAllCr7StartStop = async () => {
//   const [rows] = await pool.query(`
//     SELECT * 
//     FROM common_rail_7
//     WHERE status IN ('STOP', 'START')
//     ORDER BY idPrimary DESC
//   `);
//   return rows;
// };



















// CRUD Functions
const create = async (data) => {
  const [result] = await pool.query("INSERT INTO common_rail_7_core SET ?", data);
  return { id: result.insertId, ...data };
};

const update = async (id, data) => {
  await pool.query("UPDATE common_rail_7_core SET ? WHERE idPrimary = ?", [data, id]);
  const [rows] = await pool.query("SELECT * FROM common_rail_7_core WHERE idPrimary = ?", [id]);
  return rows[0]; // Return data yang diperbarui
};

const remove = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_7_core WHERE idPrimary = ?", [id]);
  if (rows.length === 0) {
    throw new Error("Data not found");
  }
  await pool.query("DELETE FROM common_rail_7_core WHERE idPrimary = ?", [id]);
  return { message: "Deleted successfully" };
};

module.exports = {
  getAllCr7,
  getByIdCr7,
  getAllCr7Stop,
  create,
  update,
  remove
};