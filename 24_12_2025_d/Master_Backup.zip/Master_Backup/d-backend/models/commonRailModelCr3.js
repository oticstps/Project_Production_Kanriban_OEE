// src/models/commonRailModelCr3.js

const pool = require("../config/db_core");

// Untuk common_rail_3
const getAllCr3 = async () => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3_core ORDER BY idPrimary DESC");
  return rows;
};
const getByIdCr3 = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3_core WHERE idPrimary = ?", [id]);
  return rows[0];
};
const getAllCr3Stop = async () => {
  const [rows] = await pool.query(
    "SELECT * FROM common_rail_3_core WHERE status = 'STOP' ORDER BY idPrimary DESC"
  );
  return rows;
};











// Untuk common_rail_3
const getAllCr3Hourly = async () => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3_hourly ORDER BY idPrimary DESC");
  return rows;
};
const getByIdCr3Hourly = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3 WHERE idPrimary = ?", [id]);
  return rows[0];
};
// Untuk common_rail_3_4n13
const getAllCr34n13 = async () => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3_4n13 ORDER BY idPrimary DESC");
  return rows;
};
const getByIdCr334n13 = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3_4n13 WHERE idPrimary = ?", [id]);
  return rows[0];
};
// Untuk common_rail_3_4n13_report
const getAllCr34n13Report = async () => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3_4n13_report ORDER BY idPrimary DESC");
  return rows;
};
const getByIdCr334n13Report = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3_4n13_report WHERE idPrimary = ?", [id]);
  return rows[0];
};














// CRUD Functions
const create = async (data) => {
  const [result] = await pool.query("INSERT INTO common_rail_3_core SET ?", data);
  return { id: result.insertId, ...data };
};

const update = async (id, data) => {
  await pool.query("UPDATE common_rail_3_core SET ? WHERE idPrimary = ?", [data, id]);
  const [rows] = await pool.query("SELECT * FROM common_rail_3_core WHERE idPrimary = ?", [id]);
  return rows[0]; // Return data yang diperbarui
};

const remove = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_3_core WHERE idPrimary = ?", [id]);
  if (rows.length === 0) {
    throw new Error("Data not found");
  }
  await pool.query("DELETE FROM common_rail_3_core WHERE idPrimary = ?", [id]);
  return { message: "Deleted successfully" };
};

module.exports = {
  getAllCr3,
  getByIdCr3,
  getAllCr3Stop,
  create,
  update,
  remove
};