// src/routes/commonRailRoutesCr2.js

const express = require("express");
const router = express.Router();
const controller = require("../controllers/commonRailControllerCr2");

// GET
router.get("/cr2", controller.getAllCr2);
router.get("/cr2Stop", controller.getAllCr2Stop);
router.get("/cr2/:id", controller.getByIdCr2);


// router.get("/cr2hourly", controller.getAllCr2Hourly);
// router.get("/cr2hourly/:id", controller.getByIdCr2Hourly);




// POST / PUT / DELETE
router.post("/cr2", controller.create);
router.put("/cr2/:id", controller.update);
router.delete("/cr2/:id", controller.remove);

module.exports = router;