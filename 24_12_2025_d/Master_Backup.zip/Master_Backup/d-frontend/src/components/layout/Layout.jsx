import { useState, useEffect } from 'react';
import Header from './Header';
import Sidebar from './Sidebar';

const Layout = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(() => {
    const saved = localStorage.getItem('sidebarOpen');
    return saved !== null ? JSON.parse(saved) : false;
  });

  useEffect(() => {
    localStorage.setItem('sidebarOpen', JSON.stringify(sidebarOpen));
  }, [sidebarOpen]);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  // Fungsi khusus untuk mobile toggle
  const handleMobileSidebarToggle = () => {
    setSidebarOpen(true); // Selalu buka sidebar untuk mobile
  };

  const handleSidebarClose = () => {
    // Close sidebar hanya di mobile, biarkan terbuka di desktop
    if (window.innerWidth < 1024) {
      setSidebarOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header - Fixed di atas */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-white shadow-sm">
        <Header onSidebarToggle={handleMobileSidebarToggle} />
      </div>

      {/* Sidebar - ukuran disesuaikan */}
      <aside
        className={`fixed top-16 left-0 bottom-0 z-40 shadow-lg transform transition-all duration-300 ease-in-out ${
          sidebarOpen 
            ? 'translate-x-0 w-52'  // Lebar sidebar expanded: 52 (~208px)
            : '-translate-x-full lg:translate-x-0 lg:w-14'  // Lebar sidebar collapsed: 14 (~56px)
        } bg-white text-gray-800`}
      >
        <Sidebar 
          isCollapsed={!sidebarOpen} 
          onToggle={toggleSidebar}
          onClose={handleSidebarClose} // Tambahkan prop untuk close
        />
      </aside>

      {/* Overlay untuk mobile saat sidebar muncul */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-black bg-opacity-50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        ></div>
      )}

      {/* Main Content - Jarak disesuaikan */}
      <main 
        className={`pt-16 flex-1 transition-all duration-300 ${
          sidebarOpen ? 'lg:ml-52' : 'lg:ml-14' // Margin kiri disesuaikan dengan lebar sidebar
        }`}
      >
        <div className="max-w-full mx-auto py-4 px-4 sm:px-6 lg:px-4 lg:py-4"> 
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;