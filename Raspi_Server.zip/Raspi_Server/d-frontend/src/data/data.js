import React from 'react'

export const data = () => {
  return (
    <div>data</div>
  )
}
