// insert_user.js
const pool = require('../config/db');
const bcrypt = require('bcryptjs');

const insertUser = async (username, name, pin) => {
  try {
    // Hash PIN
    const salt = await bcrypt.genSalt(12);
    const hashedPin = await bcrypt.hash(pin, salt);

    // Insert ke database
    const [result] = await pool.execute(
      'INSERT INTO users (username, name, pin, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())',
      [username, name, hashedPin]
    );

    console.log(`User inserted successfully with ID: ${result.insertId}`);
    console.log(`Username: ${username}`);
    console.log(`Name: ${name}`);
    console.log(`PIN: ${pin} (hashed in database)`);
  } catch (error) {
    console.error('Error inserting user:', error);
  }
};

// Insert user dengan NIK 234066, nama, dan PIN 123456
// Gunakan argumen command line atau langsung isi di sini
if (process.argv[2] === 'insert') {
  const username = process.argv[3] || '234066';
  const name = process.argv[4] || 'WANDA ADI B'; // Ganti dengan nama asli
  const pin = process.argv[5] || '123456';
  insertUser(username, name, pin);
} else {
  // Contoh pemanggilan langsung
  insertUser('234066', 'WANDA ADI B', '123456'); // Ganti 'John Doe' dengan nama asli
}