// src/models/commonRailModelCr5.js

const pool = require("../config/db_core");


// Untuk common_rail_5
const getAllCr5 = async () => {
  const [rows] = await pool.query("SELECT * FROM common_rail_5_core ORDER BY idPrimary DESC");
  return rows;
};

const getByIdCr5 = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_5_core WHERE idPrimary = ?", [id]);
  return rows[0];
};


const getAllCr5Stop = async () => {
  const [rows] = await pool.query(
    "SELECT * FROM common_rail_5_core WHERE status = 'STOP' ORDER BY idPrimary DESC"
  );
  return rows;
};




// Untuk common_rail_5
// const getAllCr5Hourly = async () => {
//   const [rows] = await pool.query("SELECT * FROM common_rail_5_hourly ORDER BY idPrimary DESC");
//   return rows;
// };

// const getByIdCr5Hourly = async (id) => {
//   const [rows] = await pool.query("SELECT * FROM common_rail_5 WHERE idPrimary = ?", [id]);
//   return rows[0];
// };


// const getAllCr5StartStop = async () => {
//   const [rows] = await pool.query(`
//     SELECT * 
//     FROM common_rail_5
//     WHERE status IN ('STOP', 'START')
//     ORDER BY idPrimary DESC
//   `);
//   return rows;
// };



















// CRUD Functions
const create = async (data) => {
  const [result] = await pool.query("INSERT INTO common_rail_5_core SET ?", data);
  return { id: result.insertId, ...data };
};

const update = async (id, data) => {
  await pool.query("UPDATE common_rail_5_core SET ? WHERE idPrimary = ?", [data, id]);
  const [rows] = await pool.query("SELECT * FROM common_rail_5_core WHERE idPrimary = ?", [id]);
  return rows[0]; // Return data yang diperbarui
};

const remove = async (id) => {
  const [rows] = await pool.query("SELECT * FROM common_rail_5_core WHERE idPrimary = ?", [id]);
  if (rows.length === 0) {
    throw new Error("Data not found");
  }
  await pool.query("DELETE FROM common_rail_5_core WHERE idPrimary = ?", [id]);
  return { message: "Deleted successfully" };
};

module.exports = {
  getAllCr5,
  getByIdCr5,
  getAllCr5Stop,
  create,
  update,
  remove
};