







// const express = require("express");
// const cors = require("cors");
// const dotenv = require("dotenv");
// const pool = require("./config/db_core"); // DB produksi


// dotenv.config();
// const app = express();
// app.use(cors());
// app.use(express.json());

// // Routes utama
// const authRoutes = require("./routes/auth");
// const tableRoute = require("./routes/table.route");
// const manhourRoutes = require("./routes/manhourRoutes");
// const productionRoutes = require("./routes/productionRoutes");


// // Common Rail Routes

// const commonRailRoutesCr1 = require("./routes/commonRailRoutesCr1");
// const commonRailRoutesCr2 = require("./routes/commonRailRoutesCr2");
// const commonRailRoutesCr3 = require("./routes/commonRailRoutesCr3");
// const commonRailRoutesCr4 = require("./routes/commonRailRoutesCr4");
// const commonRailRoutesCr5 = require("./routes/commonRailRoutesCr5");
// const commonRailRoutesCr6 = require("./routes/commonRailRoutesCr6");
// const commonRailRoutesCr7 = require("./routes/commonRailRoutesCr7");
// const commonRailRoutesCr8 = require("./routes/commonRailRoutesCr8");
// const commonRailRoutesCr9 = require("./routes/commonRailRoutesCr9");
// const commonRailRoutesCr10 = require("./routes/commonRailRoutesCr10");
// const commonRailRoutesCr11 = require("./routes/commonRailRoutesCr11");
// const commonRailRoutesCr12 = require("./routes/commonRailRoutesCr12");


// // Register routes
// app.use("/api/auth", authRoutes);
// app.use("/apiCr1", commonRailRoutesCr1);
// app.use("/apiCr2", commonRailRoutesCr2);
// app.use("/apiCr3", commonRailRoutesCr3);
// app.use("/apiCr4", commonRailRoutesCr4);
// app.use("/apiCr5", commonRailRoutesCr5);
// app.use("/apiCr6", commonRailRoutesCr6);
// app.use("/apiCr7", commonRailRoutesCr7);
// app.use("/apiCr8", commonRailRoutesCr8);
// app.use("/apiCr9", commonRailRoutesCr9);
// app.use("/apiCr10", commonRailRoutesCr10);
// app.use("/apiCr11", commonRailRoutesCr11);
// app.use("/apiCr12", commonRailRoutesCr12);

// app.use("/all", tableRoute);
// app.use("/api/manhour", manhourRoutes);
// app.use("/api/productions", productionRoutes);


// app.get("/", (req, res) => {
//   res.json({ message: "API is running..." });
// });


// app.use((err, req, res, next) => {
//   console.error(err.stack);
//   res.status(500).json({ message: "Something went wrong!" });
// });



// const PORT = process.env.PORT || 5500;
// app.listen(PORT, async () => {
//   try {
//     await pool.getConnection();
//     console.log("✅ DB Produksi connected");

//     await poolEnergy.getConnection();
//     console.log("✅ DB Energy connected");

//     console.log(`🚀 Server running on port ${PORT}`);
//   } catch (error) {
//     console.error("❌ Database connection failed:", error.message);
//     process.exit(1);
//   }
// });



