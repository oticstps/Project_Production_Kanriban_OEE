// const dateTime = new Date();
// const naisDateTime = dateTime.toString();
// console.log(naisDateTime);






// console.log(naisDateTime);

// // Tahun, bulan, hari
// const naisYear  = dateTime.getFullYear();        // 2025
// const naisMonth = dateTime.getMonth() + 1;       // 1–12 (WAJIB +1)
// const naisDay   = dateTime.getDate();            // 1–31

// // Waktu
// const naisHour   = dateTime.getHours();          // 0–23
// const naisMinute = dateTime.getMinutes();        // 0–59
// const naisSecond = dateTime.getSeconds();        // 0–59
// const naisMilli  = dateTime.getMilliseconds();   // 0–999

// // Tambahan (opsional)
// // const naisDayName = dateTime.toLocaleString('id-ID', { weekday: 'long' });
// // const naisMonthName = dateTime.toLocaleString('id-ID', { month: 'long' });

// // Output
// console.log({
//   naisYear,
//   naisMonth,
//   naisDay,
//   naisHour,
//   naisMinute,
//   naisSecond,
//   naisMilli,

// });








// const data = lineData.map(item => {
//   console.log(item.line);
//   console.log(item.status);
//   console.log(item.output);
//   console.log(item.downtime);
//   console.log(item.lastUpdate);


// })



const dateTime = new Date();
const naisDateTime = dateTime.toLocaleString('id-ID');

function getDayName(date) {
  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  return date.getDay();
}


