import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  BellElectric,
  Pen,
  BarChart2,
  X,
  ChevronRight,
  ChevronLeft,
  User,
  BatteryChargingIcon,
  Battery,
  Antenna
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

const Sidebar = ({ isCollapsed, onToggle, onClose }) => {
  const { user } = useAuth();

  const menuItems = [
    {
      name: 'Manhour',
      path: '/manhour',
      icon: Pen,
    },
                {
      name: 'Breakdown Manhour',
      path: '/breakdown',
      icon: Pen,
    },
    {
      name: 'Montiv',
      path: '/montiv',
      icon: BarChart2,
    },
    {
      name: 'Listrik Otics 1',
      path: '/kwh',
      icon: BatteryChargingIcon,
    },{
      name: 'Kubikal Otics 1',
      path: '/kubikal1',
      icon: BatteryChargingIcon,
    },
        {
      name: 'Listrik',
      path: '/listrik',
      icon: BatteryChargingIcon,
    },
    
    // {
    //   name: 'Tes Dua Arah Lora',
    //   path: '/lora',
    //   icon: Antenna,
    // },

  ];

  const renderToggleButton = () => {
    if (window.innerWidth < 1024) {
      return (
        <button
          onClick={onClose}
          className="text-gray-600 hover:text-gray-800 hover:bg-gray-100 p-1.5 rounded-lg transition-all duration-200"
          aria-label="Close sidebar"
        >
          <X className="w-4 h-4" />
        </button>
      );
    }
    return (
      <button
        onClick={onToggle}
        className="text-gray-600 hover:text-gray-800 hover:bg-gray-100 p-1.5 rounded-lg transition-all duration-200"
        aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {isCollapsed ? (
          <ChevronRight className="w-4 h-4" />
        ) : (
          <ChevronLeft className="w-4 h-4" />
        )}
      </button>
    );
  };

  return (
    <div className="w-full bg-white text-gray-800 min-h-screen flex flex-col border-r border-gray-200 shadow-xl">

      {/* Header */}
      <div className="p-3 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div className="flex items-center space-x-2">
              <h1 className="text-sm font-semibold text-gray-800">Menu</h1>
            </div>
          )}
          <div>{renderToggleButton()}</div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="flex-1 overflow-y-auto py-3">
          {isCollapsed ? (
            <ul className="space-y-1 px-1">
              {menuItems.map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <li key={index}>
                    <NavLink
                      to={item.path}
                      className={({ isActive }) =>
                        `flex justify-center items-center w-10 h-10 rounded-lg transition-all duration-200 ${
                          isActive
                            ? 'bg-blue-500 text-white shadow'
                            : 'text-gray-600 hover:text-gray-800 hover:bg-gray-100'
                        }`
                      }
                      onClick={() => window.innerWidth < 1024 && onClose()}
                      title={item.name} // tooltip native saat hover
                    >
                      <IconComponent className="w-4 h-4" />
                    </NavLink>
                  </li>
                );
              })}
            </ul>
          ) : (

          <ul className="space-y-0.5 px-2">
            {menuItems.map((item, index) => {
              const IconComponent = item.icon;
              return (
                <li key={index}>
                  <NavLink
                    to={item.path}
                    className={({ isActive }) =>
                      `flex items-center py-2 px-3 rounded-lg transition-all duration-200 ${
                        isActive
                          ? 'bg-gradient-to-r from-blue-500 to-indigo-500 text-white shadow-xl'
                          : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
                      }`
                    }
                    onClick={() => window.innerWidth < 1024 && onClose()}
                  >
                    <IconComponent className="w-4 h-4 mr-2.5" />
                    <span className="text-sm font-medium">{item.name}</span>
                  </NavLink>
                </li>
              );
            })}
          </ul>
        )}
      </div>

      {/* Footer */}
      {!isCollapsed && (
        <div className="p-3 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 bg-gradient-to-r from-green-500 to-teal-500 rounded-full flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-gray-900 truncate">
                {user?.name || user?.username || 'Guest'}
              </p>
              <p className="text-[0.6rem] text-gray-500 truncate">
                {user?.username || 'user@example.com'}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;



