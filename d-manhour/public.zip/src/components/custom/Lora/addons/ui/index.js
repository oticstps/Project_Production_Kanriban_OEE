// addons/ui/index.js

export { default as SerialConfig } from './SerialConfig';