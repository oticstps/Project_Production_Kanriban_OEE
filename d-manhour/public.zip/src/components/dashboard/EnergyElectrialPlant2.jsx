// EnergyElectrialPlant2.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

import Layout from '../layout/Layout';

// Jika pakai react-icons (opsional, tapi lebih profesional)
// import { FaBolt, FaMoneyBillWave, FaRecycle, FaChartLine, FaCloud, FaCO2 } from 'react-icons/fa';

const EnergyElectrialPlant2 = () => {
  const [data, setData] = useState({
    totalEnergy: 0,
    totalCost: 0,
    avgDaily: 0,
    maxShiftValue: 0,
    totalCO2: 0,
    avgDailyCO2: 0,
    shiftUsage: [],
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://172.27.6.191:4000/api/plant2/energyShiftly');
        if (response.data.success) {
          setData(response.data.data);
        } else {
          setError('Gagal memuat data.');
        }
      } catch (err) {
        setError('Koneksi ke server gagal.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const formatNumber = (num) => {
    return new Intl.NumberFormat('id-ID', { maximumFractionDigits: 1 }).format(num);
  };

  const formatCurrency = (num) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(num);
  };

  const formatKWh = (num) => {
    return `${formatNumber(num)} kWh`;
  };

  const formatCO2 = (num) => {
    return `${formatNumber(num)} kg`;
  };

  // Prepare chart data: group by date, last 20 days
  const prepareChartData = () => {
    const grouped = {};
    data.shiftUsage.forEach(item => {
      const dateStr = item.date.split('T')[0];
      if (!grouped[dateStr]) {
        grouped[dateStr] = { Shift1: 0, Shift2: 0 };
      }
      if (item.shift === "Shift 1") {
        grouped[dateStr].Shift1 = item.delta_wh;
      } else if (item.shift === "Shift 2") {
        grouped[dateStr].Shift2 = item.delta_wh;
      }
    });

    const sortedDates = Object.keys(grouped).sort();
    const last20Days = sortedDates.slice(-20);

    return last20Days.map(date => ({
      date: date, // Format YYYY-MM-DD
      'Shift 1': grouped[date].Shift1 || 0,
      'Shift 2': grouped[date].Shift2 || 0,
    }));
  };

  const chartData = prepareChartData();

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ height: '80vh' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="alert alert-danger mt-4 mx-4" role="alert">
        {error}
      </div>
    );
  }

  return (


    <Layout >
      <div
        className="container-fluid p-3"
        style={{
          fontFamily: '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif',
          backgroundColor: '#f8f9fa',
          maxWidth: '',
          margin: '0 auto',
        }}
      >
        {/* Header */}
        <div
          className="d-flex justify-content-between align-items-center mb-3"
          style={{
            backgroundColor: '#5F9EA0',
            color: 'white',
            padding: '12px 20px',
            borderRadius: '8px 8px 0 0',
          }}
        >
          <div>
            <h5 className="m-0 fw-bold">MONITORING ENERGY</h5>
            <small>Production Plant 2</small>
          </div>
          <div>
            <small>{new Date().toLocaleDateString('id-ID')}</small>
          </div>
        </div>

        {/* Stats Cards */}



        <div className="row g-3 mb-4">
          {/* Row 1: 4 Cards */}
          <div className="col-md-3">
            <div
              className="card h-100 border-0 shadow-sm"
              style={{
                backgroundColor: '#fff',
                borderRadius: '8px',
                padding: '16px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
              }}
            >
              <div className="d-flex align-items-start">
                <div
                  className="me-3"
                  style={{
                    fontSize: '1.2rem',
                    color: '#FFD700',
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '50%',
                    backgroundColor: '#FFF8E1',
                  }}
                >
                  ⚡
                </div>
                <div>
                  <small style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>Total Energy</small><br />
                  <small style={{ fontSize: '0.7rem', color: '#6c757d' }}>総エネルギー</small>
                  <h6 className="fw-bold mb-0" style={{ fontSize: '1.2rem' }}>{formatKWh(data.totalEnergy)}</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div
              className="card h-100 border-0 shadow-sm"
              style={{
                backgroundColor: '#fff',
                borderRadius: '8px',
                padding: '16px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
              }}
            >
              <div className="d-flex align-items-start">
                <div
                  className="me-3"
                  style={{
                    fontSize: '1.2rem',
                    color: '#28a745',
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '50%',
                    backgroundColor: '#E8F5E9',
                  }}
                >
                  💰
                </div>
                <div>
                  <small style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>Total Cost</small><br />
                  <small style={{ fontSize: '0.7rem', color: '#6c757d' }}>総コスト</small>
                  <h6 className="fw-bold mb-0" style={{ fontSize: '1.2rem' }}>{formatCurrency(data.totalCost / 1000)}</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div
              className="card h-100 border-0 shadow-sm"
              style={{
                backgroundColor: '#fff',
                borderRadius: '8px',
                padding: '16px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
              }}
            >
              <div className="d-flex align-items-start">
                <div
                  className="me-3"
                  style={{
                    fontSize: '1.2rem',
                    color: '#6f42c1',
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '50%',
                    backgroundColor: '#F3E5F5',
                  }}
                >
                  🔄
                </div>
                <div>
                  <small style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>Avg Daily</small><br />
                  <small style={{ fontSize: '0.7rem', color: '#6c757d' }}>一日平均</small>
                  <h6 className="fw-bold mb-0" style={{ fontSize: '1.2rem' }}>{formatKWh(data.avgDaily)}</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div
              className="card h-100 border-0 shadow-sm"
              style={{
                backgroundColor: '#fff',
                borderRadius: '8px',
                padding: '16px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
              }}
            >
              <div className="d-flex align-items-start">
                <div
                  className="me-3"
                  style={{
                    fontSize: '1.2rem',
                    color: '#fd7e14',
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '50%',
                    backgroundColor: '#FFE0B2',
                  }}
                >
                  📈
                </div>
                <div>
                  <small style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>Max Shift Value</small><br />
                  <small style={{ fontSize: '0.7rem', color: '#6c757d' }}>最大シフト値</small>
                  <h6 className="fw-bold mb-0" style={{ fontSize: '1.2rem' }}>{formatKWh(data.maxShiftValue)}</h6>
                </div>
              </div>
            </div>
          </div>
          <div>
              
          </div>


          
          {/* Row 2: 2 Cards */}
          <div className="col-md-3">
            <div
              className="card h-100 border-0 shadow-sm"
              style={{
                backgroundColor: '#fff',
                borderRadius: '8px',
                padding: '16px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
              }}
            >
              <div className="d-flex align-items-start">
                <div
                  className="me-3"
                  style={{
                    fontSize: '1.2rem',
                    color: '#6c757d',
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '50%',
                    backgroundColor: '#ECEFF1',
                  }}
                >
                  🌫️
                </div>
                <div>
                  <small style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>Total CO Emissions</small><br />
                  <small style={{ fontSize: '0.7rem', color: '#6c757d' }}>総CO2排出量</small>
                  <h6 className="fw-bold mb-0" style={{ fontSize: '1.2rem' }}>{formatCO2(data.totalCO2)}</h6>
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-3">
            <div
              className="card h-100 border-0 shadow-sm"
              style={{
                backgroundColor: '#fff',
                borderRadius: '8px',
                padding: '16px',
                boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
              }}
            >
              <div className="d-flex align-items-start">
                <div
                  className="me-3"
                  style={{
                    fontSize: '1.2rem',
                    color: '#17a2b8',
                    width: '32px',
                    height: '32px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '50%',
                    backgroundColor: '#E0F7FA',
                  }}
                >
                  ☁️
                </div>
                <div>
                  <small style={{ fontSize: '0.8rem', fontWeight: 'bold' }}>Avg Daily CO Emissions</small><br />
                  <small style={{ fontSize: '0.7rem', color: '#6c757d' }}>一日平均CO2排出量</small>
                  <h6 className="fw-bold mb-0" style={{ fontSize: '1.2rem' }}>{formatCO2(data.avgDailyCO2)}</h6>
                </div>
              </div>
            </div>
          </div>



        </div>

        {/* Chart Section */}
        <div className="card border-0 shadow-sm" style={{
          backgroundColor: '#fff',
          borderRadius: '8px',
          padding: '16px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
        }}>
          <div className="d-flex justify-content-between align-items-center mb-3">
            <h6 className="fw-bold mb-0" style={{ fontSize: '1rem' }}>Shift Usage (Shift 1 & Shift 2)</h6>
            <small className="text-muted" style={{ fontSize: '0.8rem' }}>Last 20 days</small>
          </div>
          <div style={{ height: 400 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{ top: 10, right: 20, left: 20, bottom: 60 }}
              >
                <CartesianGrid stroke="#eee" strokeDasharray="3 3" />
                <XAxis
                  dataKey="date"
                  angle={-45}
                  textAnchor="end"
                  height={60}
                  tick={{ fontSize: 10 }}
                  interval={0}
                />
                <YAxis
                  tick={{ fontSize: 10 }}
                  label={{ value: 'kWh', angle: -90, position: 'insideLeft', offset: -10, fontSize: 11 }}
                  domain={[0, 'auto']}
                />
                <Tooltip
                  formatter={(value) => [`${value} kWh`, 'Value']}
                  labelFormatter={(label) => `Date: ${label}`}
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    fontSize: '12px',
                  }}
                />
                <Legend verticalAlign="top" height={36} />
                <Bar dataKey="Shift 1" name="Shift 1" fill="#ADD8E6" barSize={20} />
                <Bar dataKey="Shift 2" name="Shift 2" fill="#00008B" barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>





      </div>
    </Layout>
  );
};

export default EnergyElectrialPlant2;