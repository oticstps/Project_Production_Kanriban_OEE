import React from 'react'
import Layout from '../layout/Layout';
import LineProductionStatus from './ManhourBreakdown/LineProductionStatus'
import CR9 from './ManhourBreakdown/CommonRail9Dashboard'

const ManhourBreakdown = () => {
  return (
    <Layout>
      {/* <div>ManhourBreakdown</div> */}
      <CR9 />
    </Layout>
  )
}

export default ManhourBreakdown;